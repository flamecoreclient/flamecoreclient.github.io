# Bootpack v1.0.0

- Webpack
- Bootstrap 4
- Perfect Scroll
- Lazy Load

- Material Icons
- Font Awesome

Author @andikachamberlin

Powered by Flamecore Organization
http://flamecore.pro